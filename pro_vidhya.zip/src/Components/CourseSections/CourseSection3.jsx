import { Box, Card, Divider, Paper, Stack, Typography, useMediaQuery } from '@mui/material';
import React, { useEffect, useState } from 'react'
import Grid from '@mui/material/Grid2';
import PropTypes from 'prop-types';
import { useTheme } from '@mui/material/styles';
import AppBar from '@mui/material/AppBar';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Network from '../../Netwrok';

const TabPanel = ({ children, value, index, ...other }) => {
    return (
        <div role="tabpanel" hidden={value !== index} {...other}>
            {value === index && <Box sx={{ p: 3 }}>{children}</Box>}
        </div>
    );
};

TabPanel.propTypes = {
    children: PropTypes.node,
    index: PropTypes.number.isRequired,
    value: PropTypes.number.isRequired,
};

function a11yProps(index) {
    return {
        id: `full-width-tab-${index}`,
        'aria-controls': `full-width-tabpanel-${index}`,
    };
}


const CourseSection3 = () => {

    const isMobile = useMediaQuery("(min-width:600px)");
    const theme = useTheme();
    const [value, setValue] = useState(0);
    const [courses, setCourses] = useState([]);
    const instId = 152;

    const handleChange = (event, newValue) => {
        setValue(newValue);
    };

    const auth = 'eyJ1c2VySWQiOjc4MSwidGltZXN0YW1wIjoxNzM4MzExODg2OTIyLCJleHBpcnkiOjE3NjgzMTE4ODY5MjJ9';
    const [domainData, setDomainData] = useState([]);
    const [employee, setEmployee] = useState([]);

    const getDomainList = async () => {
        try {
            const response = await Network.fetchDomain(auth);
            let filterCA = response?.domains.filter((item) => item?.name === "CA");

            if (filterCA.length > 0) {
                setDomainData(filterCA[0].child);
            }
        } catch (error) {
            console.log(error);
        };
    };

    const getAllCourses = async () => {
        try {
            const response = await Network.fetchCourses(instId);

            let activeCourses = [];
            let testSeriesCourses = [];

            response.courses.forEach((course) => {
                if (course.active === true) {
                    activeCourses.push(course);

                    const hasMatchingDomain = domainData.some(domain => domain.name === activeCourses?.domain?.name);

                    if (hasMatchingDomain && course?.tags?.some(tag => tag?.tag === "Trending Courses")) {
                        testSeriesCourses.push(course);
                    }
                }
            });

            setCourses(testSeriesCourses);
        } catch (error) {
            console.log(error);
        };
    };

    const getEmployee = async () => {
        try {
            const response = await Network.fetchEmployee(instId);
            let filterEmployee = response.employees.filter((item) => item?.name === "CA");
            setEmployee(filterEmployee);
        } catch (error) {
            console.log(error);
        }
    };

    console.log('employee', employee);

    useEffect(() => {
        getEmployee();
        getAllCourses();
        getDomainList();
    }, []);

    return (
        <div style={{ paddingLeft: isMobile ? '6rem' : '1rem', paddingRight: isMobile ? '6rem' : '1rem', paddingTop: isMobile ? '2rem' : '1rem', paddingBottom: isMobile ? '2rem' : '1rem' }}>
            <Grid container spacing={2}>
                <Grid item size={{ xs: 12, sm: 12, md: 12, lg: 12 }}>
                    <Box sx={{ bgcolor: 'background.paper', width: '100%' }}>
                        <AppBar position="static">
                            <Tabs
                                value={value}
                                onChange={handleChange}
                                indicatorColor="secondary"
                                textColor="inherit"
                                variant="fullWidth"
                                aria-label="full width tabs example"
                            >
                                {
                                    domainData.map((item, i) => {
                                        return (
                                            <Tab key={i} label={item?.name} {...a11yProps(0)} />
                                        )
                                    })
                                }
                            </Tabs>
                        </AppBar>
                        <Typography
                            fontSize={isMobile ? '25px' : '18px'}
                            fontWeight={'600'}
                            textAlign={isMobile ? 'start' : 'center'}
                            py={2}
                        >
                            Tranding Courses
                        </Typography>
                        {courses.map((item, index) => (
                            <TabPanel key={index} value={value} index={index} dir={theme.direction}>
                                {item?.title || `Content for ${item?.title}`}
                            </TabPanel>
                        ))}
                    </Box>
                </Grid>
            </Grid>
        </div>
    )
}

export default CourseSection3